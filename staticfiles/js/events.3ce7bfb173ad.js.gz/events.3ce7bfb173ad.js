// var EventEmitter = require('events');
// const DropZone = require('./sidebar/sidebar-dropzone.jsx');
//
// DropZone.emitter.on('UPLOAD_COMPLETED', loadLayers());
// var = EventHandler {
//   function loadLayers() {
//       console.log('loading...')
//       var geojsonModelLayer = new L.GeoJSON.AJAX('load_layers/');
//       geojsonModelLayer.addTo(map);
//   }
// }
//
// var eventManager {
//
// }
