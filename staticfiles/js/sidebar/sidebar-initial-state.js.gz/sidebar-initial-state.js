export default {
    getState: function () {
        return {
            layers: [],
            incoming_upload: false,
            active_layers: []
        };
    }
};
