export default {
    getState: function () {
        return {
            is_uploading: false,
            dataLayers: [],
            is_loading_to_map: false
        };
    }
};
