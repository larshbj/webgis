import * as Redux from "redux";
import rootReducer from "./reducer";

export default Redux.createStore(rootReducer);